kodi plugin for olevod

using command outside of this folder to zip

```shell
rm oversea.zip
zip -r -0  oversea.zip plugin.video.overseaplayer -x "*/.*" -x "*/*.pyo"
```